﻿Public Class LeagueApp
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnInfo_Click(sender As Object, e As EventArgs) Handles btnInfo.Click
        MessageBox.Show("Version: " + vbTab + vbTab + "1.0" + vbNewLine + "Created by: " + vbTab + "Charles" + vbNewLine + "IGN: " + vbTab + vbTab + "Zeke Yeager" + vbNewLine + "E-mail: " + vbTab + vbTab + "chobocharles@gmail.com", "Info", MessageBoxButtons.OK, MessageBoxIcon.Question)
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        If listChampions.SelectedItem = "Aatrox" Then
            Process.Start("http://na.op.gg/champion/aatrox/statistics/top")
        ElseIf listChampions.SelectedItem = "Ahri" Then
            Process.Start("http://na.op.gg/champion/ahri/statistics")
        ElseIf listChampions.SelectedItem = "Akali" Then
            Process.Start("http://na.op.gg/champion/akali/statistics")
        ElseIf listChampions.SelectedItem = "Alistar" Then
            Process.Start("http://na.op.gg/champion/alistar/statistics")
        ElseIf listChampions.SelectedItem = "Amumu" Then
            Process.Start("http://na.op.gg/champion/amumu/statistics")
        ElseIf listChampions.SelectedItem = "Anivia" Then
            Process.Start("http://na.op.gg/champion/anivia/statistics")
        ElseIf listChampions.SelectedItem = "Annie" Then
            Process.Start("http://na.op.gg/champion/annie/statistics")
        ElseIf listChampions.SelectedItem = "Ashe" Then
            Process.Start("http://na.op.gg/champion/ashe/statistics")
        ElseIf listChampions.SelectedItem = "Aurelion Sol" Then
            Process.Start("http://na.op.gg/champion/aurelionsol/statistics")
        ElseIf listChampions.SelectedItem = "Azir" Then
            Process.Start("http://na.op.gg/champion/azir/statistics")
        ElseIf listChampions.SelectedItem = "Bard" Then
            Process.Start("http://na.op.gg/champion/bard/statistics")
        ElseIf listChampions.SelectedItem = "Blitzcrank" Then
            Process.Start("http://na.op.gg/champion/blitzcrank/statistics")
        ElseIf listChampions.SelectedItem = "Brand" Then
            Process.Start("http://na.op.gg/champion/brand/statistics")
        ElseIf listChampions.SelectedItem = "Braum" Then
            Process.Start("http://na.op.gg/champion/braum/statistics")
        ElseIf listChampions.SelectedItem = "Caitlyn" Then
            Process.Start("http://na.op.gg/champion/caitlyn/statistics")
        ElseIf listChampions.SelectedItem = "Camille" Then
            Process.Start("http://na.op.gg/champion/camille/statistics")
        ElseIf listChampions.SelectedItem = "Cassiopeia" Then
            Process.Start("http://na.op.gg/champion/cassiopeia/statistics")
        ElseIf listChampions.SelectedItem = "Cho'Gath" Then
            Process.Start("http://na.op.gg/champion/chogath/statistics")
        ElseIf listChampions.SelectedItem = "Corki" Then
            Process.Start("http://na.op.gg/champion/corki/statistics")
        ElseIf listChampions.SelectedItem = "Darius" Then
            Process.Start("http://na.op.gg/champion/darius/statistics")
        ElseIf listChampions.SelectedItem = "Diana" Then
            Process.Start("http://na.op.gg/champion/diana/statistics")
        ElseIf listChampions.SelectedItem = "Draven" Then
            Process.Start("http://na.op.gg/champion/draven/statistics")
        ElseIf listChampions.SelectedItem = "Dr. Mundo" Then
            Process.Start("http://na.op.gg/champion/drmundo/statistics")
        ElseIf listChampions.SelectedItem = "Ekko" Then
            Process.Start("http://na.op.gg/champion/ekko/statistics")
        ElseIf listChampions.SelectedItem = "Elise" Then
            Process.Start("http://na.op.gg/champion/elise/statistics")
        ElseIf listChampions.SelectedItem = "Evelynn" Then
            Process.Start("http://na.op.gg/champion/evelynn/statistics")
        ElseIf listChampions.SelectedItem = "Ezreal" Then
            Process.Start("http://na.op.gg/champion/ezreal/statistics")
        ElseIf listChampions.SelectedItem = "Fiddlesticks" Then
            Process.Start("http://na.op.gg/champion/fiddlesticks/statistics")
        ElseIf listChampions.SelectedItem = "Fiora" Then
            Process.Start("http://na.op.gg/champion/fiora/statistics")
        ElseIf listChampions.SelectedItem = "Fizz" Then
            Process.Start("http://na.op.gg/champion/fizz/statistics")
        ElseIf listChampions.SelectedItem = "Galio" Then
            Process.Start("http://na.op.gg/champion/galio/statistics")
        ElseIf listChampions.SelectedItem = "Gangplank" Then
            Process.Start("http://na.op.gg/champion/gangplank/statistics")
        ElseIf listChampions.SelectedItem = "Garen" Then
            Process.Start("http://na.op.gg/champion/garen/statistics")
        ElseIf listChampions.SelectedItem = "Gnar" Then
            Process.Start("http://na.op.gg/champion/gnar/statistics")
        ElseIf listChampions.SelectedItem = "Gragas" Then
            Process.Start("http://na.op.gg/champion/gragas/statistics")
        ElseIf listChampions.SelectedItem = "Graves" Then
            Process.Start("http://na.op.gg/champion/graves/statistics")
        ElseIf listChampions.SelectedItem = "Hecarim" Then
            Process.Start("http://na.op.gg/champion/hecarim/statistics")
        ElseIf listChampions.SelectedItem = "Heimerdinger" Then
            Process.Start("http://na.op.gg/champion/heimerdinger/statistics")
        ElseIf listChampions.SelectedItem = "Illaoi" Then
            Process.Start("http://na.op.gg/champion/illaoi/statistics")
        ElseIf listChampions.SelectedItem = "Irelia" Then
            Process.Start("http://na.op.gg/champion/irelia/statistics")
        ElseIf listChampions.SelectedItem = "Ivern" Then
            Process.Start("http://na.op.gg/champion/ivern/statistics")
        ElseIf listChampions.SelectedItem = "Janna" Then
            Process.Start("http://na.op.gg/champion/janna/statistics")
        ElseIf listChampions.SelectedItem = "Jarvan IV" Then
            Process.Start("http://na.op.gg/champion/jarvaniv/statistics")
        ElseIf listChampions.SelectedItem = "Jax" Then
            Process.Start("http://na.op.gg/champion/jax/statistics")
        ElseIf listChampions.SelectedItem = "Jayce" Then
            Process.Start("http://na.op.gg/champion/jayce/statistics")
        ElseIf listChampions.SelectedItem = "Jhin" Then
            Process.Start("http://na.op.gg/champion/jhin/statistics")
        ElseIf listChampions.SelectedItem = "Jinx" Then
            Process.Start("http://na.op.gg/champion/jinx/statistics")
        ElseIf listChampions.SelectedItem = "Kalista" Then
            Process.Start("http://na.op.gg/champion/kalista/statistics")
        ElseIf listChampions.SelectedItem = "Karma" Then
            Process.Start("http://na.op.gg/champion/karma/statistics")
        ElseIf listChampions.SelectedItem = "Karthus" Then
            Process.Start("http://na.op.gg/champion/karthus/statistics")
        ElseIf listChampions.SelectedItem = "Kassadin" Then
            Process.Start("http://na.op.gg/champion/kassadin/statistics")
        ElseIf listChampions.SelectedItem = "Katarina" Then
            Process.Start("http://na.op.gg/champion/katarina/statistics")
        ElseIf listChampions.SelectedItem = "Kayle" Then
            Process.Start("http://na.op.gg/champion/kayle/statistics")
        ElseIf listChampions.SelectedItem = "Kayn" Then
            Process.Start("http://na.op.gg/champion/kayn/statistics")
        ElseIf listChampions.SelectedItem = "Kennen" Then
            Process.Start("http://na.op.gg/champion/kennen/statistics")
        ElseIf listChampions.SelectedItem = "Kha'zix" Then
            Process.Start("http://na.op.gg/champion/khazix/statistics")
        ElseIf listChampions.SelectedItem = "Kindred" Then
            Process.Start("http://na.op.gg/champion/kindred/statistics")
        ElseIf listChampions.SelectedItem = "Kled" Then
            Process.Start("http://na.op.gg/champion/kled/statistics")
        ElseIf listChampions.SelectedItem = "Kog'Maw" Then
            Process.Start("http://na.op.gg/champion/kogmaw/statistics")
        ElseIf listChampions.SelectedItem = "Leblanc" Then
            Process.Start("http://na.op.gg/champion/leblanc/statistics")
        ElseIf listChampions.SelectedItem = "Lee Sin" Then
            Process.Start("http://na.op.gg/champion/leesin/statistics")
        ElseIf listChampions.SelectedItem = "Leona" Then
            Process.Start("http://na.op.gg/champion/leona/statistics")
        ElseIf listChampions.SelectedItem = "Lissandra" Then
            Process.Start("http://na.op.gg/champion/lissandra/statistics")
        ElseIf listChampions.SelectedItem = "Lucian" Then
            Process.Start("http://na.op.gg/champion/lucian/statistics")
        ElseIf listChampions.SelectedItem = "Lulu" Then
            Process.Start("http://na.op.gg/champion/lucian/statistics")
        ElseIf listChampions.SelectedItem = "Lux" Then
            Process.Start("http://na.op.gg/champion/lux/statistics")
        ElseIf listChampions.SelectedItem = "Malphite" Then
            Process.Start("http://na.op.gg/champion/malphite/statistics")
        ElseIf listChampions.SelectedItem = "Malzahar" Then
            Process.Start("http://na.op.gg/champion/malzahar/statistics")
        ElseIf listChampions.SelectedItem = "Maokai" Then
            Process.Start("http://na.op.gg/champion/maokai/statistics")
        ElseIf listChampions.SelectedItem = "Master Yi" Then
            Process.Start("http://na.op.gg/champion/masteryi/statistics")
        ElseIf listChampions.SelectedItem = "Miss Fortune" Then
            Process.Start("http://na.op.gg/champion/missfortune/statistics")
        ElseIf listChampions.SelectedItem = "Mordekaiser" Then
            Process.Start("http://na.op.gg/champion/mordekaiser/statistics")
        ElseIf listChampions.SelectedItem = "Morgana" Then
            Process.Start("http://na.op.gg/champion/morgana/statistics")
        ElseIf listChampions.SelectedItem = "Nami" Then
            Process.Start("http://na.op.gg/champion/nami/statistics")
        ElseIf listChampions.SelectedItem = "Nasus" Then
            Process.Start("http://na.op.gg/champion/nasus/statistics")
        ElseIf listChampions.SelectedItem = "Nautilus" Then
            Process.Start("http://na.op.gg/champion/nautilus/statistics")
        ElseIf listChampions.SelectedItem = "Nidalee" Then
            Process.Start("http://na.op.gg/champion/nidalee/statistics")
        ElseIf listChampions.SelectedItem = "Nocturne" Then
            Process.Start("http://na.op.gg/champion/nocturne/statistics")
        ElseIf listChampions.SelectedItem = "Nunu" Then
            Process.Start("http://na.op.gg/champion/nocturne/statistics")
        ElseIf listChampions.SelectedItem = "Olaf" Then
            Process.Start("http://na.op.gg/champion/olaf/statistics")
        ElseIf listChampions.SelectedItem = "Orianna" Then
            Process.Start("http://na.op.gg/champion/orianna/statistics")
        ElseIf listChampions.SelectedItem = "Ornn" Then
            Process.Start("http://na.op.gg/champion/ornn/statistics")
        ElseIf listChampions.SelectedItem = "Pantheon" Then
            Process.Start("http://na.op.gg/champion/pantheon/statistics")
        ElseIf listChampions.SelectedItem = "Poppy" Then
            Process.Start("http://na.op.gg/champion/poppy/statistics")
        ElseIf listChampions.SelectedItem = "Quinn" Then
            Process.Start("http://na.op.gg/champion/quinn/statistics")
        ElseIf listChampions.SelectedItem = "Rakan" Then
            Process.Start("http://na.op.gg/champion/rakan/statistics")
        ElseIf listChampions.SelectedItem = "Rammus" Then
            Process.Start("http://na.op.gg/champion/rammus/statistics")
        ElseIf listChampions.SelectedItem = "Rek'Sai" Then
            Process.Start("http://na.op.gg/champion/reksai/statistics")
        ElseIf listChampions.SelectedItem = "Renekton" Then
            Process.Start("http://na.op.gg/champion/renekton/statistics")
        ElseIf listChampions.SelectedItem = "Rengar" Then
            Process.Start("http://na.op.gg/champion/rengar/statistics")
        ElseIf listChampions.SelectedItem = "Riven" Then
            Process.Start("http://na.op.gg/champion/riven/statistics")
        ElseIf listChampions.SelectedItem = "Rumble" Then
            Process.Start("http://na.op.gg/champion/rumble/statistics")
        ElseIf listChampions.SelectedItem = "Ryze" Then
            Process.Start("http://na.op.gg/champion/ryze/statistics")
        ElseIf listChampions.SelectedItem = "Sejuani" Then
            Process.Start("http://na.op.gg/champion/sejuani/statistics")
        ElseIf listChampions.SelectedItem = "Shaco" Then
            Process.Start("http://na.op.gg/champion/shaco/statistics")
        ElseIf listChampions.SelectedItem = "Shen" Then
            Process.Start("http://na.op.gg/champion/shen/statistics")
        ElseIf listChampions.SelectedItem = "Shyvana" Then
            Process.Start("http://na.op.gg/champion/shyvana/statistics")
        ElseIf listChampions.SelectedItem = "Singed" Then
            Process.Start("http://na.op.gg/champion/singed/statistics")
        ElseIf listChampions.SelectedItem = "Sion" Then
            Process.Start("http://na.op.gg/champion/sion/statistics")
        ElseIf listChampions.SelectedItem = "Sivir" Then
            Process.Start("http://na.op.gg/champion/sivir/statistics")
        ElseIf listChampions.SelectedItem = "Skarner" Then
            Process.Start("http://na.op.gg/champion/sivir/statistics")
        ElseIf listChampions.SelectedItem = "Sona" Then
            Process.Start("http://na.op.gg/champion/sona/statistics")
        ElseIf listChampions.SelectedItem = "Soraka" Then
            Process.Start("http://na.op.gg/champion/soraka/statistics")
        ElseIf listChampions.SelectedItem = "Swain" Then
            Process.Start("http://na.op.gg/champion/swain/statistics")
        ElseIf listChampions.SelectedItem = "Syndra" Then
            Process.Start("http://na.op.gg/champion/syndra/statistics")
        ElseIf listChampions.SelectedItem = "Tahm Kench" Then
            Process.Start("http://na.op.gg/champion/tahmkench/statistics")
        ElseIf listChampions.SelectedItem = "Taliyah" Then
            Process.Start("http://na.op.gg/champion/taliyah/statistics")
        ElseIf listChampions.SelectedItem = "Talon" Then
            Process.Start("http://na.op.gg/champion/talon/statistics")
        ElseIf listChampions.SelectedItem = "Taric" Then
            Process.Start("http://na.op.gg/champion/taric/statistics")
        ElseIf listChampions.SelectedItem = "Teemo" Then
            Process.Start("http://na.op.gg/champion/teemo/statistics")
        ElseIf listChampions.SelectedItem = "Thresh" Then
            Process.Start("http://na.op.gg/champion/thresh/statistics")
        ElseIf listChampions.SelectedItem = "Tristana" Then
            Process.Start("http://na.op.gg/champion/tristana/statistics")
        ElseIf listChampions.SelectedItem = "Trundle" Then
            Process.Start("http://na.op.gg/champion/trundle/statistics")
        ElseIf listChampions.SelectedItem = "Tryndamere" Then
            Process.Start("http://na.op.gg/champion/tryndamere/statistics")
        ElseIf listChampions.SelectedItem = "Twisted Fate" Then
            Process.Start("http://na.op.gg/champion/tryndamere/statistics")
        ElseIf listChampions.SelectedItem = "Twitch" Then
            Process.Start("http://na.op.gg/champion/twitch/statistics")
        ElseIf listChampions.SelectedItem = "Udyr" Then
            Process.Start("http://na.op.gg/champion/udyr/statistics")
        ElseIf listChampions.SelectedItem = "Urgot" Then
            Process.Start("http://na.op.gg/champion/urgot/statistics")
        ElseIf listChampions.SelectedItem = "Varus" Then
            Process.Start("http://na.op.gg/champion/varus/statistics")
        ElseIf listChampions.SelectedItem = "Vayne" Then
            Process.Start("http://na.op.gg/champion/vayne/statistics")
        ElseIf listChampions.SelectedItem = "Veigar" Then
            Process.Start("http://na.op.gg/champion/veigar/statistics")
        ElseIf listChampions.SelectedItem = "Vel'Koz" Then
            Process.Start("http://na.op.gg/champion/velkoz/statistics")
        ElseIf listChampions.SelectedItem = "Vi" Then
            Process.Start("http://na.op.gg/champion/vi/statistics")
        ElseIf listChampions.SelectedItem = "Viktor" Then
            Process.Start("http://na.op.gg/champion/viktor/statistics")
        ElseIf listChampions.SelectedItem = "Vladimir" Then
            Process.Start("http://na.op.gg/champion/vladimir/statistics")
        ElseIf listChampions.SelectedItem = "Volibear" Then
            Process.Start("http://na.op.gg/champion/volibear/statistics")
        ElseIf listChampions.SelectedItem = "Warwick" Then
            Process.Start("http://na.op.gg/champion/warwick/statistics")
        ElseIf listChampions.SelectedItem = "Wukong" Then
            Process.Start("http://na.op.gg/champion/monkeyking/statistics")
        ElseIf listChampions.SelectedItem = "Xayah" Then
            Process.Start("http://na.op.gg/champion/xayah/statistics")
        ElseIf listChampions.SelectedItem = "Xerath" Then
            Process.Start("http://na.op.gg/champion/xerath/statistics")
        ElseIf listChampions.SelectedItem = "Xin Zhao" Then
            Process.Start("http://na.op.gg/champion/xinzhao/statistics")
        ElseIf listChampions.SelectedItem = "Yasuo" Then
            Process.Start("http://na.op.gg/champion/yasuo/statistics")
        ElseIf listChampions.SelectedItem = "Yorick" Then
            Process.Start("http://na.op.gg/champion/yorick/statistics")
        ElseIf listChampions.SelectedItem = "Zac" Then
            Process.Start("http://na.op.gg/champion/zac/statistics")
        ElseIf listChampions.SelectedItem = "Zed" Then
            Process.Start("http://na.op.gg/champion/zed/statistics")
        ElseIf listChampions.SelectedItem = "Ziggs" Then
            Process.Start("http://na.op.gg/champion/ziggs/statistics")
        ElseIf listChampions.SelectedItem = "Zilean" Then
            Process.Start("http://na.op.gg/champion/zilean/statistics")
        ElseIf listChampions.SelectedItem = "Zyra" Then
            Process.Start("http://na.op.gg/champion/zyra/statistics")
        Else
            MessageBox.Show("You need to select a champion first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

End Class
